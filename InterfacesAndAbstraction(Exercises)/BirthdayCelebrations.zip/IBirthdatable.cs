﻿using System;

public interface IBirthdatable 
{
    string Birthdate { get; }
}