﻿using System;

public interface IBirthable
{
    string BirthDate { get; }
}