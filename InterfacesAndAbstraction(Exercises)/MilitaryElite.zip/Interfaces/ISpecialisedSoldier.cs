﻿using System;

public interface ISpecialisedSoldier
{
    string Corps { get; }
}