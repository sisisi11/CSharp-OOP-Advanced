﻿public interface ISpy
{
    string CodeNumber { get; }
}