﻿using System;

public interface IPrivate
{
    double Salary { get; }
}