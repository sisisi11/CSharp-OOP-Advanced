﻿using System;

public interface IAcceleratable
{
    string PushGas();
}