﻿using System;

public interface IBrakable
{
    string Brake();
}