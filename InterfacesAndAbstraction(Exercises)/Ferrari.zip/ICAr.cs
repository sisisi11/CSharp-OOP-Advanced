﻿using System;

public interface ICar
{
    string Driver { get; }
}
