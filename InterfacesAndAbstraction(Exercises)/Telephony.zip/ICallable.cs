﻿using System;

public interface ICallable
{
    void CallNumber(string number);
}