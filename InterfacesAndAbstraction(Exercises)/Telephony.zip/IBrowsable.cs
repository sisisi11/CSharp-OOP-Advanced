﻿using System;

public interface IBrowsable
{
    void BrowseSites(string site);
}